import './App.css';
import FormTodo from './Components/FormTodo.jsx'
function App() {
  return (
    <>
      <FormTodo />
    </>
  );
}

export default App;