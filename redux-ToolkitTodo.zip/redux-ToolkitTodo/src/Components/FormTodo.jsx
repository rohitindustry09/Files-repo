import { useState, useRef } from 'react';
import './FormTodo.css';
import { v4 as uuidv4 } from 'uuid';

export default function FormTodo() {
  let [formData, setFormData] = useState([
    { id: 123, name: 'David' }
  ]);
  let [inputValue, setInputValue] = useState('');
  let [editId, setEditId] = useState(null);
  let [editValue, setEditValue] = useState('');
  let editInputRef = useRef(null);
  
  function handleInputValue(e) {
    setInputValue(e.target.value);
  }
  //adding
  function handleSubmit(e) {
    e.preventDefault();
    if (inputValue !== '') {
     setFormData((prevData)=> [
       ...prevData,
       { id: uuidv4(), name: inputValue }
     ]);
     setInputValue('');
    }
  }
  //removing
  function handleDelete(id) {
    setFormData((prevData)=> (
      prevData.filter((item)=> item.id !== id)
    ));
  }
  //setEditingRow
  function startEditing(id, value) {
    setEditId(id);
    setEditValue(value);
    setTimeout(function() {
      editInputRef.current.focus()
    }, 10);
  }
  function cancelEditing() {
    setEditId(null);
  }
  function handleEditChange(e) {
    setEditValue(e.target.value);
  }
  function saveEdit(id) {
    setFormData((prevData)=> 
     prevData.map((item)=> 
       item.id === id ? { ...item, name: editValue } : item
    ));
    setEditId(null);
    setEditValue('');
  }

 return (
  <>
   <h1> Form Todo </h1>
   <form onSubmit={handleSubmit}>
      <input type="text" 
        placeholder="enter name"
        value={inputValue}
        onChange={handleInputValue}
      />
      <button 
        className="btn">
        Add +
      </button>
   </form>
   <ul>
     {
       formData.map((data)=> (
        <>
         <li key={data.id}>
           {
             editId === data.id ?
            <>
             <input type="text" value={editValue}
              onChange={handleEditChange}
              ref={editInputRef}
             />
          <div className="states-delete-edit">
             <button className="color"
              onClick={()=>saveEdit(data.id)}
             >Save</button>
             <button 
              onClick={()=>cancelEditing()}>Cancel</button>
          </div>
            </>
           : 
          <>
           {data.name}
            <div className="states-delete-edit">
            <button className="color"
             onClick={()=> startEditing(data.id, data.name)}>
              <i className="bi bi-pen"></i>
            </button>
            <button
              onClick={()=> handleDelete(data.id)}>
              <i className="bi bi-trash"></i>
            </button>
           </div>
          </>
           }
         </li>
        </>
       ))
     }
   </ul>
  </>
 );
}